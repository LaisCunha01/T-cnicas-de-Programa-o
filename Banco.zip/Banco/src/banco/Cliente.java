/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Cliente {
    private int idCliente;
    private String nome;
    private String cpf;
    private String email;

    public Cliente(int idCliente, String nome, String cpf, String eMail) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.cpf = cpf;
        this.email = eMail;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    
    

    @Override
    public String toString() {
        return "\n Cliente numero: "+ this.idCliente
                + "\n Nome: "+ this.nome
                + "\n Cpf: "+ this.cpf
                + "\n e-mail: "+ this.email;
    }
    
    
}
