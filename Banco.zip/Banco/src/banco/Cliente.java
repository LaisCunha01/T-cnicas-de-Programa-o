/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Cliente {
    public int idCliente;
    public String nome;
    public String cpf;
    public String eMail;
    public String numero;
    public String saldo;
    public Object titular;

    public Cliente(int idCliente, String nome, String cpf, String eMail) {
        this.idCliente = idCliente;
        this.nome = nome;
        this.cpf = cpf;
        this.eMail = eMail;
    }
    
    
    
    public String mostraDados(){
        return "\n Cliente numero: "+ this.idCliente
                + "\n Nome: "+ this.nome
                + "\n Cpf: "+ this.cpf
                + "\n e-mail: "+ this.eMail;
    }
    
  @Override
    public String toString(){
         return "\n Conta Numero: "+ this.numero+ 
                 "\n Titular: "+ this.titular.mostraDados()+
                 "\n Saldo R$: "+ this.saldo ;
    }
}
