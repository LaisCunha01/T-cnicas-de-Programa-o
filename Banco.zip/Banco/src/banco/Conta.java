/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Conta {
    public int numero;
    public Cliente titular;
    public double saldo;
    private String idCliente;
    private String nome;
    private String cpf;
    private String eMail;
    
    public Conta(){}
    
    public Conta(int numero){
        this.numero=numero;
    }
    public Conta(int numero, Cliente titular, double saldo) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
    }
      
    
    public void depositar(double valor){
        this.saldo+=valor;
    }
    
    public boolean sacar(double valor){
        if(this.saldo>=valor){
            this.saldo-=valor;
            return true;
        }else{
            return false;
        }
    }
    
    public boolean transferir(double valor, Conta destino){
     if(this.sacar(valor)){
         destino.depositar(valor);
         return true;
     }else{
         return false;
     }   
    }  
     public String mostraDados(){
         return "\n Conta Numero: "+ this.numero+
                 "\n Titular: "+ this.titular.mostraDados()  +
                 "\n Saldo R$: "+ this.saldo ;
     }
     
    @Override
     public String toString(){
         return "\n Cliente numero: "+ this.idCliente
                + "\n Nome: "+ this.nome
                + "\n Cpf: "+ this.cpf
                + "\n e-mail: "+ this.eMail;
     }  
}
