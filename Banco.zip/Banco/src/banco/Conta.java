/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Conta implements Comparable<Conta>{
    private int numero;
    private Cliente titular;
    private double saldo;
    //sobrecarga
    public Conta(){}
    
    public Conta(int numero){
        this.numero=numero;
    }
    public Conta(int numero, Cliente titular, double saldo) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
    }
      // getters e setters

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void setTitular(Cliente titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    
    public void depositar(double valor){
        this.saldo+=valor;
    }
    
    public boolean sacar(double valor){
        if(this.saldo>=valor){
            this.saldo-=valor;
            return true;
        }else{
            return false;
        }
    }
    
    public boolean transferir(double valor, Conta destino){
     if(this.sacar(valor)){
         destino.depositar(valor);
         return true;
     }else{
         return false;
     }   
    }  
     
    @Override
    public String toString() {
        return "\n Conta Numero: "+ this.numero+
                 " Titular: "+ this.getTitular().getNome()+
                  "Saldo R$: "+ this.saldo ;
    }

     
@Override

public int compareTo (Conta outra) {
    // Ordenação por Saldo (Crescente)
    if (this.getSaldo() < outra.getSaldo()) {
        return -1; // Esta conta vem antes pois o saldo é menor
    }
    if (this.getSaldo() > outra.getSaldo()) {
        return 1;  // Esta conta vem depois pois o saldo é maior
    }
    return 0; // Saldos iguais 
}
    
    
}
