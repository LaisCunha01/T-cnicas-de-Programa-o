/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco;

import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JOptionPane;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Conta>lista= new ArrayList<>();
        lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Carol Primer", "12345678900", "carolprimer@mail.com"), 20000.50));
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Carlos Primer", "12345678900", "carlosprimer@mail.com"),120.50));
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Roberto Carlos", "12345685900", "carlosroberto@mail.com"),1200.50));
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Gabriella Silva", "12345678900", "GabriellaSilva@mail.com"), 120000.50));
         System.out.println(lista);
         //Collections.sort(lista);
       /* Funcionario f=new Funcionario("João da Silva","jao@gmail.com",1600);
        System.out.println(f);
        //alterar e-mail
        System.out.println(f);*/
        
        
        
        
        
        
        
    }
    
}
