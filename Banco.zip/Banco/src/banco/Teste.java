/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Teste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /*Cliente cli= new Cliente(1,"Pedro Junior","123.456.789-09","pedro@gmail.com");
        Conta c= new Conta(123,cli,500);
        Conta c1= new Conta(134,
                    new Cliente(2,"Rafela Pereira","873.456.222-09","rafa@gmail.com"),
                      250);
          */     
        
        ArrayList<Conta>lista= new ArrayList<>();
        lista.add(new Conta(1, new Cliente(1, "Carol Primer", "12345678900", "carolprimer@mail.com"), 20000.50));
        lista.add(new Conta(1, new Cliente(1, "Carol Primer", "12345678900", "carolprimer@mail.com"), 20000.50));
        lista.add(new Conta(3));
        
        //imprimir o titular da segunda conta
        JOptionPane.showMessageDialog(null, lista.get(1).titular);
   
       
    }
    
}
