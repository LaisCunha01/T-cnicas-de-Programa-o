/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Funcionario {
    //atributos
    public double salario;
    //construtor
    public Funcionario(double salario){
        this.salario= salario;
    }
    //métodos
    public void recebeAumento(double percentual){
        double aumento;
        aumento= this.salario* (percentual/100);
        this.salario+=aumento;
    }
    public double ganhoAnual(){
        return this.salario*12;
    }
    
}
