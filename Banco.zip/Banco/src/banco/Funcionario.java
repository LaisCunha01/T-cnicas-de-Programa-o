/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Funcionario {
    //atributos
    private String nome;
    private String email;
    private double salario;
    //construtor
    //public Funcionario(){}
    public Funcionario(String nome,String email,double salario){
        this.nome= nome;
        this.email=email;
        this.salario= salario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    


//métodos
    public void recebeAumento(double percentual){
        double aumento;
        aumento= this.salario* (percentual/100);
        this.salario+=aumento;
    }
    public double ganhoAnual(){
        return this.salario*12;
    }

    @Override
    public String toString() {
        return ("\n Nome: "+ this.nome + " E-mail: "
                +this.email + " Salário R$ "+ this.salario);
    }
    
    
    
}
