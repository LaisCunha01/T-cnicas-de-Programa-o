/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Banco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Conta> lista= new ArrayList<>();
        String menu= "\n 1-Abrir Conta" +
        "\n 2- Sacar \n 3- Depositar\n 4- Mostrar dados\n 5- Transferir \n 6- Listar todas as contas \n 0- Sair"+
        "\n Escolha a opção: ";
         int op,posatual=0,posdestino=1;//Posicao da conta no ArrayList  
        String titular;
        int numero;
        double saldo;
        String dados;
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Carol Primer", "12345678900", "carolprimer@mail.com"), 20000.50));
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Carlos Primer", "12345678900", "carlosprimer@mail.com"),120.50));
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Roberto Carlos", "12345685900", "carlosroberto@mail.com"),1200.50));
         lista.add(new Conta(lista.size()+1, new Cliente(lista.size()+1, "Gabriella Silva", "12345678900", "GabriellaSilva@mail.com"), 120000.50));
        double valor;
        do{
            op= Integer.parseInt(JOptionPane.showInputDialog(menu));
            switch (op) {
                case 1:
                    lista.add(new Conta(lista.size()+1,new Cliente(lista.size()+1,JOptionPane.showInputDialog("Digite o nome do cliente"),JOptionPane.showInputDialog("Digite o cpf do cliente"),JOptionPane.showInputDialog("Digite o e-mail do cliente")),100));
                    break;
                case 2:
                    valor= Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do saque"));
                    if(lista.get(posatual).sacar(valor)){
                         JOptionPane.showMessageDialog(null, "Operação realizada com sucesso!");
                    }else{
                         JOptionPane.showMessageDialog(null, "Operação não realizada!");
                    }
                    break;
                case 3:
                     valor= Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do depósito"));
                     lista.get(posatual).depositar(valor);
                     break;
                case 4:
                    JOptionPane.showMessageDialog(null, lista.get(posatual));
                    break;
                case 5:
                    valor= Double.parseDouble(JOptionPane.showInputDialog("Digite o valor da transferência"));
                    if(lista.get(posatual).transferir(valor, lista.get(posdestino))){
                         JOptionPane.showMessageDialog(null, "Operação realizada com sucesso!");
                    }else{
                         JOptionPane.showMessageDialog(null, "Operação não realizada!");
                    }
                    break;
                    case 6:
                        dados="";
                        for (Conta c: lista){
                          numero=c.getNumero();
                          titular= c.getTitular().getNome();
                          saldo= c.getSaldo();
                          dados+= "\n Conta Número: " +numero+ "\n Titular: "+titular+ "\n Saldo: " +saldo;
                        }
                        
                    JOptionPane.showMessageDialog(null,dados);
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Até Logo!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção Inválida");
            }
        }while(op!=0);
            
                      
        
        
        
        
        
    }
    
}
