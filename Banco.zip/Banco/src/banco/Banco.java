/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco;

import javax.swing.JOptionPane;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Banco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String menu= "\n 1-Abrir Conta" +
        "\n 2- Sacar \n 3- Depositar\n 4- Mostrar dados\n 5- Transferir \n 0- Sair"+
        "\n Escolha a opção: ";
         int op;      
        Conta c1=new Conta(1, new Cliente(1, "Carol Primer", "12345678900", "carolprimer@mail.com"), 20000.50);
        Conta destino= new Conta(1, new Cliente(1, "Carol Primer", "12345678900", "carolprimer@mail.com"), 20000.50);
        Conta c= new Conta(3);
        do{
            op= Integer.parseInt(JOptionPane.showInputDialog(menu));
            switch (op) {
                case 1: 
                    String nome=  JOptionPane.showInputDialog("Digite o nome do cliente");
                    String email= JOptionPane.showInputDialog("Digite o email do cliente");
                    String cpf= JOptionPane.showInputDialog("Digite o cpf do cliente");
                    c=new Conta (3, new Cliente(3,nome, cpf, email),100);
                    break;
                case 2:         
                double valor = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do saque: "));
                    if(c1.sacar(valor)){
                        JOptionPane.showMessageDialog(null,"Operação realizada com sucesso!");
                    }else{
                        JOptionPane.showMessageDialog(null,"Operação não realizada!");
                    }
                    break;
                case 3:
                 
                    break;

                case 4:
                    
                    break;
                case 5:
                    valor=  Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do transferir: "));
                    if(c1.transferir(valor, destino))
                    break;
                case 0:
                    JOptionPane.showMessageDialog(null, "Até Logo!");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção Inválida");
            }

        }while(op!=0);
         
        System.out.println(c1);
        System.out.println(c1.titular);
    }
}

  
